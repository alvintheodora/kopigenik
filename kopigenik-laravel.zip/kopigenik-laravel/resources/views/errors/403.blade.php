@extends('layouts.app')

@section('title','Unauthorized user')

@section('content')
	<!--body-->
	<div class="container-fluid text-center">
		<div class="alert alert-danger"><h2>Unauthorized access</h2></div>
		<a href="/">Go to Home</a>
	</div>
@endsection