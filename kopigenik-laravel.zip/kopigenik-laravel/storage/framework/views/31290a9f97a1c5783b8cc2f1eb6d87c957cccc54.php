<?php $__env->startSection('title','Payment Approval'); ?>

<?php $__env->startSection('content'); ?>
	<!--body-->
	<div class="container-fluid">
		<h2>To be Approved</h2>
		<ul>
			<?php $__currentLoopData = $transactions_tba; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				
				
					<li><a href="\transactions\<?php echo e($transaction->id); ?>">ID: <?php echo e($transaction->id); ?></a>, Time bought: <?php echo e($transaction->time_bought); ?>

					</li>				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>

		<h2>To be Confirmed</h2>
		<ul>
			<?php $__currentLoopData = $transactions_tbc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				
				
					<li><a href="\transactions\<?php echo e($transaction->id); ?>">ID: <?php echo e($transaction->id); ?></a>, Time bought: <?php echo e($transaction->time_bought); ?>

					</li>				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>

		<h2>Approved</h2>
		<ul>
			<?php $__currentLoopData = $transactions_approved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				
				
					<li><a href="\transactions\<?php echo e($transaction->id); ?>">ID: <?php echo e($transaction->id); ?></a>, Time bought: <?php echo e($transaction->time_bought); ?>

					</li>				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
		</ul>		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>