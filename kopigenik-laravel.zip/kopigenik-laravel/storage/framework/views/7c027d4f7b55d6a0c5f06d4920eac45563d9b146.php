<?php $__env->startSection('title','Check Shipment'); ?>

<?php $__env->startSection('content'); ?>
	<!--body-->
	<div class="container-fluid">
		<h1 class="text-center">My Subscriptions</h1>
		<h2>On Progress</h2>
		<ul>
			<?php $__currentLoopData = $shipments_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				
				
					<li><a href="\check-shipments\<?php echo e($shipment->id); ?>">ID: <?php echo e($shipment->transaction->id); ?></a>, 
						Plan: <?php echo e($shipment->transaction->plan->name); ?> (<?php echo e($shipment->transaction->subscribe_duration); ?> months), 
						Delivery Address: <?php echo e($shipment->address . ', ' . $shipment->district . ', ' . $shipment->city . ', ' . $shipment->province . ', ' . $shipment->zipcode); ?>, 
						Total shipment left: <?php echo e($shipment->total_shipment_left); ?>

					</li>
				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>

		<h2>On Hold</h2>
		<ul>
			<?php $__currentLoopData = $shipments_user_tb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				
			
					<li><a href="\check-shipments\<?php echo e($shipment->id); ?>">ID: <?php echo e($shipment->transaction->id); ?></a>, Plan: <?php echo e($shipment->transaction->plan->name); ?> (<?php echo e($shipment->transaction->subscribe_duration); ?> months), Time bought: <?php echo e($shipment->transaction->time_bought); ?>, Status: <?php echo e($shipment->transaction->status); ?>


						<?php if($shipment->transaction->status=="to be confirmed"): ?>
							<a class="btn btn-primary" style="margin-left: 10px;" href="/payment-confirmation/<?php echo e($shipment->transaction->id); ?>">Show payment confirmation detail</a>

							<button class="btn btn-danger" style="margin-left: 10px;" type="button" data-toggle="modal" data-target="#removeModal">Remove</button>

							<!-- Modal -->
							<form action="\remove-transaction\<?php echo e($shipment->transaction->id); ?>" method="POST">
								<?php echo e(csrf_field()); ?>

								<div class="modal fade" id="removeModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
								  <div class="modal-dialog" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								        <h4 class="modal-title" id="myModalLabel">Cancel Transaction?</h4>
								      </div>
								      <div class="modal-body">
								      	<p>Are you sure to cancel the transaction?</p>
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>								        
							        	<button type="submit" class="btn btn-danger">Yes</button>
								      </div>
								    </div>
								  </div>
								</div>
							</form>
						<?php endif; ?>

					</li>
				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>

		<h2>Finished Orders</h2>
		<ul>
			<?php $__currentLoopData = $shipments_user_finished; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				
				
					<li><a href="\check-shipments\<?php echo e($shipment->id); ?>">ID: <?php echo e($shipment->transaction->id); ?></a>, Plan: <?php echo e($shipment->transaction->plan->name); ?> (<?php echo e($shipment->transaction->subscribe_duration); ?> months), Last Delivery Date: <?php echo e($shipment->last_delivery_date); ?>

					</li>
				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>