<?php $__env->startSection('title','Payment Approval'); ?>

<?php $__env->startSection('content'); ?>
	<!--body-->
	<div class="container-fluid">
		<h2>Transaction ID: <?php echo e($transaction->id); ?></h2>
		<p><span>Name: <?php echo e($transaction->user->name); ?></span></p>
		<p><span>Plan: <?php echo e($transaction->plan->name); ?></span></p>
		<p><span>Price: <?php echo e($transaction->price); ?></span></p>
		<p><span>Bank: <?php echo e($transaction->bank_account); ?></span></p>
		<p><span>Account Holder: <?php echo e($transaction->account_holder); ?></span></p>
		<p><span>Account Number: <?php echo e($transaction->account_number); ?></span></p>

		<p><span>Time bought: <?php echo e($transaction->time_bought); ?></span></p>
		<p><span>Time confirmed: <?php echo e($transaction->time_confirmed); ?></span></p>
		<p><span>Time approved: <?php echo e($transaction->time_approved); ?></span></p>
		<p><span>Status: <?php echo e($transaction->status); ?></span></p>

		<?php if($transaction->status == 'to be approved'): ?>
			<form action="\transactions\<?php echo e($transaction->id); ?>" method="POST">
				<?php echo e(csrf_field()); ?>

					<button class="btn btn-lg btn-success btn-block" type="submit">Approve</button>	
			</form>		
		<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>